/* License
 * This file is part of FTPbox - Copyright (C) 2012-2013 ftpbox.org
 * FTPbox is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published 
 * by the Free Software Foundation, either version 3 of the License, or (at your option) any later version. This program is distributed 
 * in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 * See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with this program. 
 * If not, see <http://www.gnu.org/licenses/>.
 */
/* FileLog.cs
 * Manage (read/write) the File/Folder Log
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace FTPboxLib
{
    [JsonObject(MemberSerialization.OptIn)]
	public class FileLog
	{
        [JsonProperty("Items")]
        public List<FileLogItem> Files { get; private set; }

        [JsonProperty]
        public List<string> Folders { get; private set; }

        private readonly AccountController _controller;

        public FileLog(AccountController account)
        {
            _controller = account;

            Files = new List<FileLogItem>();
            Folders = new List<string>();

			Log.Write(l.Info, "Opened FileLog");
		}

	    #region Methods

        /// <summary>
        /// Puts the specified file in the File Log and saves to the config file
        /// </summary>
        public void PutFile(SyncQueueItem file)
        {
            Log.Write(l.Debug, "Putting file {0} to log", file.NewCommonPath);
            if (Contains(file.NewCommonPath)) Remove(file.NewCommonPath);

            Files.Add(new FileLogItem
            {
                CommonPath = file.NewCommonPath,
                Local = file.SyncTo == SyncTo.Remote ? file.Item.LastWriteTime : File.GetLastWriteTime(file.LocalPath),
                Remote = _controller.Client.GetLwtOf(file.NewCommonPath)
            });

            Settings.SaveProfile();
            Notifications.ChangeRecentList();
        }

        /// <summary>
        /// Removed the file with the path specified from the Files list
        /// </summary>
        /// <param name="path"></param>
	    public void Remove(string path)
	    {
	        var fl = new List<FileLogItem>(Files);
	        foreach (var fi in fl.Where(f => f.CommonPath == path))
	            Files.Remove(fi);

	        Log.Write(l.Debug, "*** Removed from Log: {0}", path);
            Notifications.ChangeRecentList();
	    }

        /// <summary>
        /// Puts the specified folder in the Folder Log and saves to the config file
        /// </summary>
        /// <param name="cpath"></param>
        /// <param name="oldName">Used when renaming a folder to also rename any of its subitems in the logs</param>
        public void PutFolder(string cpath, string oldName = null)
	    {
            if (oldName != null && Folders.Contains(oldName))
            {
                Files.Each( (f,i) =>
                    {
                        if (f.CommonPath.StartsWith(oldName + "/"))
                            Files[i].CommonPath = cpath + f.CommonPath.Substring(oldName.Length);
                    });
                Folders.Each ((f, i) =>
                    {
                        if (f.StartsWith(oldName + "/") || f.Equals(oldName))
                            Folders[i] = cpath + f.Substring(oldName.Length);
                    });
            }
            if (!Folders.Contains(cpath))
	            Folders.Add(cpath);
	        Settings.SaveProfile();
	    }

	    /// <summary>
	    /// removes the specified folder from log
	    /// </summary>
	    /// <param name="cpath"></param>
	    public void RemoveFolder(string cpath)
	    {
	        if (Folders.Contains(cpath))
	            Folders.Remove(cpath);
	        Settings.SaveProfile();
            Notifications.ChangeRecentList();
        }

        public DateTime GetLocal(string path)
        {
            var ret = DateTime.MinValue;

            foreach (var fi in Files)
                if (fi.CommonPath == path)
                    return fi.Local;
            return ret;
        }

        public DateTime GetRemote(string path)
        {
            var ret = DateTime.MinValue;

            foreach (var fi in Files)
                if (fi.CommonPath == path)
                    return fi.Remote;
            return ret;
        }

        public bool Contains(string path)
        {
            var ret = false;
            foreach (var fi in Files)
                if (fi.CommonPath == path)
                    ret = true;
            return ret;
        }

        public bool IsEmpty()
        {
            return Files.Count == 0 && Folders.Count == 0;
        }

	    #endregion

    }
}